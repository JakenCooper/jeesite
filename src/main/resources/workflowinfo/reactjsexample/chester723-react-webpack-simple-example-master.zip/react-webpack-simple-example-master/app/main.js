/**
 * Copyright (c) 2014 Meizu bigertech, All rights reserved.
 * http://www.bigertech.com/
 * @author Chester
 * @date  15/8/25
 * @description
 *
 */
var React = require('react');
var AppComponent = require('../productBox.js');
//React.render(<AppComponent />, document.getElementById('content'));
